using Newtonsoft.Json;

namespace LodgeLink.Model
{
    public class MachineData
    {
    public Machine[]? Value { get; set; }
    }
    public class Machine
    {
    [JsonProperty("computerDnsName")]
    public string computerDnsName { get; set; }
    [JsonProperty("osPlatform")]
    public string osPlatform { get; set; }
    }
}