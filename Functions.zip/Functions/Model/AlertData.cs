using Newtonsoft.Json;

namespace LodgeLink.Model
{
     public class AlertData
    {
    public Alert[]? Value { get; set; }
    }
    public class Alert
    {
        [JsonProperty("incidentId")]
        public string incidentId { get; set; }
        [JsonProperty("category")]
        public string category { get; set; }
        [JsonProperty("title")]
        public string title { get; set; }
        [JsonProperty("description")]
        public string description { get; set; }
        [JsonProperty("severity")]
        public string severity { get; set; }
        [JsonProperty("classification")]
        public string classification { get; set; }
        [JsonProperty("computerDnsName")]
        public string computerDnsName { get; set; }
        [JsonProperty("alertCreationTime")]
        public string alertCreationTime { get; set; }

        //[JsonProperty("relatedUser")]
        //public string relatedUser { get; set; }
        //[JsonProperty("comments")]
        //public string comments { get; set; }
        //[JsonProperty("evidence")]
        //public string evidence { get; set; }
    }
}