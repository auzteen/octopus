using Newtonsoft.Json;

namespace LodgeLink.Model
{

    public class Auth0Data
    {
        [JsonProperty("date")]
        public string date { get; set; }
        [JsonProperty("user_name")]
        public string user_name { get; set; }
        [JsonProperty("client_ip")]
        public string client_ip { get; set; }
        [JsonProperty("description")]
        public string description { get; set; }
        [JsonProperty("connection")]
        public string connection { get; set; }
        [JsonProperty("ip")]
        public string ip { get; set; }
        [JsonProperty("client_id")]
        public string client_id { get; set; }
        [JsonProperty("connection_id")]
        public string connection_id { get; set; }
        [JsonProperty("user_id")]
        public string user_id { get; set; }
        
    }
}