using Newtonsoft.Json;

namespace LodgeLink.Model
{
    public class RecommendationData
    {
        public Recommendation[]? Value { get; set; }
    }
    public class Recommendation
    {
        [JsonProperty("productName")]
        public string productName { get; set; }
        [JsonProperty("recommendationName")]
        public string recommendationName { get; set; }
        [JsonProperty("weakness")]
        public string weakness { get; set; }
        [JsonProperty("severityScore")]
        public string severityScore { get; set; }
    }
}