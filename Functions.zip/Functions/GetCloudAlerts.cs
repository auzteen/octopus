using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using LodgeLink.Model;


namespace Lodgelink
{
    public static class GetCloudAlerts
    {
        private static HttpClient httpClient = new HttpClient();
        private static string GET_URL = "https://management.azure.com/subscriptions/83f5f98e-391d-4a9e-8b32-ffc89cf9cbd8/providers/Microsoft.Security/alerts?api-version=2022-01-01"; // Change these uri for GET

        [FunctionName("GetCloudAlerts")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

                //#region Defender Alerts
                //string token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJodHRwczovL21hbmFnZW1lbnQuY29yZS53aW5kb3dzLm5ldCIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2YxNWEwNTJjLWI3MWMtNDIwNS1hN2ZhLTRiMTFlMjA5ZjUzYS8iLCJpYXQiOjE2NzU2NTM0NzAsIm5iZiI6MTY3NTY1MzQ3MCwiZXhwIjoxNjc1NjU3NzUzLCJhY3IiOiIxIiwiYWlvIjoiQVZRQXEvOFRBQUFBSWNET3RwWjFQR3lyaGNMUWZPeGl0SXZyRCtLR0x5N0RmUjN5NDFaaytLdU9HZDRTU0I5SEI3NURjRkJsM3ZBczBSUytwYXlRMDFuZHltSnBnUDJTYzA3NFZVQ2pGR1Q0MnlRZ1FVZk5WOVU9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJhcHBpZCI6IjE4ZmJjYTE2LTIyMjQtNDVmNi04NWIwLWY3YmYyYjM5YjNmMyIsImFwcGlkYWNyIjoiMCIsImZhbWlseV9uYW1lIjoiVWt3dSIsImdpdmVuX25hbWUiOiJBdXN0aW4iLCJncm91cHMiOlsiZjk1YTBkMmEtYzk1ZS00MzgyLWI5MDgtNmQ4OTRmYmQwODE0IiwiM2Q2NzQ5M2QtYTM3Yy00Y2YxLWExYzQtMjJmOTI0NzU1ZDlmIiwiNDcwMWVmOTItMWFhNC00OTk3LTg3OGItMGIzYzhkODY0ODc5IiwiZWEwNDc3MjAtYWUzNS00ZmJmLWFiNzktMjczNzgwMTVmYTc1IiwiYWNhNWQ1YTQtYWU2Mi00MjA3LWFiZWItZDYzOGRhM2FjOWQ1IiwiN2U4OTI4YzUtZGM5OC00MDg3LWJlN2YtMmUwNWZlMjU3Y2E5Il0sImlwYWRkciI6IjI0LjY1LjEyMC4yMTEiLCJuYW1lIjoiQXVzdGluIFVrd3UiLCJvaWQiOiIzMTIzMGY4Ni01OGQ3LTQyZDYtYjk4ZS04YTU3YzA5ODQxY2EiLCJwdWlkIjoiMTAwMzIwMDFGNjczMDdDRCIsInB3ZF9leHAiOiIxMTcyNTU2IiwicHdkX3VybCI6Imh0dHBzOi8vcG9ydGFsLm1pY3Jvc29mdG9ubGluZS5jb20vQ2hhbmdlUGFzc3dvcmQuYXNweCIsInJoIjoiMC5BU3dBTEFWYThSeTNCVUtuLWtzUjRnbjFPa1pJZjNrQXV0ZFB1a1Bhd2ZqMk1CTXNBTVEuIiwic2NwIjoidXNlcl9pbXBlcnNvbmF0aW9uIiwic3ViIjoiQUZPU2wzcmpiRzZCeEk2WDNXaGQ0ZkZuSW1TNC1iUEtMZlRmZE9VQ0xsNCIsInRpZCI6ImYxNWEwNTJjLWI3MWMtNDIwNS1hN2ZhLTRiMTFlMjA5ZjUzYSIsInVuaXF1ZV9uYW1lIjoiYXVrd3VAbG9kZ2VsaW5rLm9ubWljcm9zb2Z0LmNvbSIsInVwbiI6ImF1a3d1QGxvZGdlbGluay5vbm1pY3Jvc29mdC5jb20iLCJ1dGkiOiJ2aEk0OUhXek4wS245MTdPN1dFZEFBIiwidmVyIjoiMS4wIiwid2lkcyI6WyI5Yjg5NWQ5Mi0yY2QzLTQ0YzctOWQwMi1hNmFjMmQ1ZWE1YzMiLCI2MmU5MDM5NC02OWY1LTQyMzctOTE5MC0wMTIxNzcxNDVlMTAiLCIxOTRhZTRjYi1iMTI2LTQwYjItYmQ1Yi02MDkxYjM4MDk3N2QiLCJiNzlmYmY0ZC0zZWY5LTQ2ODktODE0My03NmIxOTRlODU1MDkiXSwieG1zX3RjZHQiOjE1MzAyMTU0Nzl9.N2EXivGFnOvu4e1BffoaVIynm6HIUhZ752WnbkP6tXKi66hnYhKxiBs6cBSYQR4WvbxWWi2Exj0LwV4z4w832Al9doVIKIgL792KIQBhYvC9a4jrcBWiX1w2yiX59kJ6E_CCOJ9BF_T_LywzKomMq9l7jW2iYInr6TQLQGPna_YETazUzhYITkgEshXugUjvGVbhBPTw1algvN146Je6Qhny8bICp5lS0JChTvGnIw1bHwndg-riM31bw3PSKjz4e-b5VwISu6kp8VYF6iCbcSES8GMnz8vMUV0jjo2RyVZfpcrODj5j0Wptsj6XFl3gdkK7lTpTNoVKGy_F7E7cYQ";
                var request = new HttpRequestMessage(HttpMethod.Get, GET_URL);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", GetToken()); //token
                var response = httpClient.SendAsync(request).GetAwaiter().GetResult();
                var result = response.Content.ReadAsStringAsync();
                var responseData = JsonConvert.DeserializeObject<AlertData>(result.Result);
                //#endregion
                log.LogInformation(result.Result);

                if (responseData != null && responseData.Value?.Length > 0)
                {
                    var jsonObject = JsonConvert.SerializeObject(responseData, new JsonSerializerSettings
                    {
                        Formatting = Formatting.Indented
                    });
                }

            return new OkObjectResult(responseData);
        }

        public static string GetToken()
        {
            string tenantId = "f15a052c-b71c-4205-a7fa-4b11e209f53a";
            string appId = "08fe282b-18ff-4968-940e-5a57211ea338";
            string appSecret = "jG08Q~lsTfRgjr0oOxrm8-Va3YWeTrFB2czo.bOb";
            const string authority = "https://login.microsoftonline.com";
            const string audience = "https://management.core.windows.net"; //"05a65629-4c1b-48c1-a78b-804c4abdd4af";
            IConfidentialClientApplication myApp = ConfidentialClientApplicationBuilder.Create(appId).WithClientSecret(appSecret).WithAuthority($"{authority}/{tenantId}/oauth2/token").Build();
            List<string> scopes = new List<string>() { $"{audience}/.default" };
            AuthenticationResult authResult = myApp.AcquireTokenForClient(scopes).ExecuteAsync().GetAwaiter().GetResult();
            return authResult.AccessToken;
        }


    } 

}