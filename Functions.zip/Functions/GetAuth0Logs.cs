using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using LodgeLink.Model;
using Auth0.AspNetCore.Authentication;
using Microsoft.IdentityModel.Tokens;


namespace Lodgelink
{
    public static class GetAuth0Logs
    {
        private static HttpClient httpClient = new HttpClient();
        private static string GET_URL = "https://lodgelink-prod.auth0.com/api/v2/logs"; // Change these uri for GET

        [FunctionName("GetAuth0Logs")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

                //#region Defender Alerts
                string token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik5VVXlOalV4TURoQ05FVkdRek5CTlVZMVFrVkdSVVV5T1RkQlJrWTRSakUwUmtZM09VRkJOdyJ9.eyJpc3MiOiJodHRwczovL2xvZGdlbGluay1wcm9kLmF1dGgwLmNvbS8iLCJzdWIiOiJISzhZcWo5YzVtYjF3eDJqZkhBYlVCOGRia1RCZEhnZEBjbGllbnRzIiwiYXVkIjoiaHR0cHM6Ly9sb2RnZWxpbmstcHJvZC5hdXRoMC5jb20vYXBpL3YyLyIsImlhdCI6MTY3NTY1ODExNSwiZXhwIjoxNjc1NzQ0NTE1LCJhenAiOiJISzhZcWo5YzVtYjF3eDJqZkhBYlVCOGRia1RCZEhnZCIsInNjb3BlIjoicmVhZDpjbGllbnRfZ3JhbnRzIGNyZWF0ZTpjbGllbnRfZ3JhbnRzIGRlbGV0ZTpjbGllbnRfZ3JhbnRzIHVwZGF0ZTpjbGllbnRfZ3JhbnRzIHJlYWQ6dXNlcnMgdXBkYXRlOnVzZXJzIGRlbGV0ZTp1c2VycyBjcmVhdGU6dXNlcnMgcmVhZDp1c2Vyc19hcHBfbWV0YWRhdGEgdXBkYXRlOnVzZXJzX2FwcF9tZXRhZGF0YSBkZWxldGU6dXNlcnNfYXBwX21ldGFkYXRhIGNyZWF0ZTp1c2Vyc19hcHBfbWV0YWRhdGEgY3JlYXRlOnVzZXJfdGlja2V0cyByZWFkOmNsaWVudHMgdXBkYXRlOmNsaWVudHMgZGVsZXRlOmNsaWVudHMgY3JlYXRlOmNsaWVudHMgcmVhZDpjbGllbnRfa2V5cyB1cGRhdGU6Y2xpZW50X2tleXMgZGVsZXRlOmNsaWVudF9rZXlzIGNyZWF0ZTpjbGllbnRfa2V5cyByZWFkOmNvbm5lY3Rpb25zIHVwZGF0ZTpjb25uZWN0aW9ucyBkZWxldGU6Y29ubmVjdGlvbnMgY3JlYXRlOmNvbm5lY3Rpb25zIHJlYWQ6cmVzb3VyY2Vfc2VydmVycyB1cGRhdGU6cmVzb3VyY2Vfc2VydmVycyBkZWxldGU6cmVzb3VyY2Vfc2VydmVycyBjcmVhdGU6cmVzb3VyY2Vfc2VydmVycyByZWFkOmRldmljZV9jcmVkZW50aWFscyB1cGRhdGU6ZGV2aWNlX2NyZWRlbnRpYWxzIGRlbGV0ZTpkZXZpY2VfY3JlZGVudGlhbHMgY3JlYXRlOmRldmljZV9jcmVkZW50aWFscyByZWFkOnJ1bGVzIHVwZGF0ZTpydWxlcyBkZWxldGU6cnVsZXMgY3JlYXRlOnJ1bGVzIHJlYWQ6cnVsZXNfY29uZmlncyB1cGRhdGU6cnVsZXNfY29uZmlncyBkZWxldGU6cnVsZXNfY29uZmlncyByZWFkOmVtYWlsX3Byb3ZpZGVyIHVwZGF0ZTplbWFpbF9wcm92aWRlciBkZWxldGU6ZW1haWxfcHJvdmlkZXIgY3JlYXRlOmVtYWlsX3Byb3ZpZGVyIGJsYWNrbGlzdDp0b2tlbnMgcmVhZDpzdGF0cyByZWFkOnRlbmFudF9zZXR0aW5ncyB1cGRhdGU6dGVuYW50X3NldHRpbmdzIHJlYWQ6bG9ncyByZWFkOnNoaWVsZHMgY3JlYXRlOnNoaWVsZHMgZGVsZXRlOnNoaWVsZHMgdXBkYXRlOnRyaWdnZXJzIHJlYWQ6dHJpZ2dlcnMgcmVhZDpncmFudHMgZGVsZXRlOmdyYW50cyByZWFkOmd1YXJkaWFuX2ZhY3RvcnMgdXBkYXRlOmd1YXJkaWFuX2ZhY3RvcnMgcmVhZDpndWFyZGlhbl9lbnJvbGxtZW50cyBkZWxldGU6Z3VhcmRpYW5fZW5yb2xsbWVudHMgY3JlYXRlOmd1YXJkaWFuX2Vucm9sbG1lbnRfdGlja2V0cyByZWFkOnVzZXJfaWRwX3Rva2VucyBjcmVhdGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiBkZWxldGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiByZWFkOmN1c3RvbV9kb21haW5zIGRlbGV0ZTpjdXN0b21fZG9tYWlucyBjcmVhdGU6Y3VzdG9tX2RvbWFpbnMgcmVhZDplbWFpbF90ZW1wbGF0ZXMgY3JlYXRlOmVtYWlsX3RlbXBsYXRlcyB1cGRhdGU6ZW1haWxfdGVtcGxhdGVzIiwiZ3R5IjoiY2xpZW50LWNyZWRlbnRpYWxzIn0.nw4L0b5MgjHv3ihIIQ7OgqxRAyY0Lum5WQ3-kSP_EJKztGF0An81W-FRaQ0DqJRAqE6nl6_VGe7FhX4z54Z6T7IW7UMAVLd_3zZrXSCP3uzR-dPryKLMEsUQAXfgNmrKIH75k3Gjl91IEXzX3GKawsj34FA7DI5bsrB-ABnGBgamUesEkbPAD5-x9_zS6gHQP-PEpQhaBuY7x1Hr6oKsKV88KTywBootgpLP1IFlEwLJp6AjAnfmgGwQMznNl_t-Db6pmXjDEqmsbzjfuSkwS2aEX2ktLO-b7Moe7t0d9BObcR9_4MbVftktbI2LXHs070Lxe4wV9JPdQQTVsfitog";
                var request = new HttpRequestMessage(HttpMethod.Get, GET_URL);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
                var response = httpClient.SendAsync(request).GetAwaiter().GetResult();
                var result = response.Content.ReadAsStringAsync();
                var responseData = JsonConvert.DeserializeObject<List<Auth0Data>>(result.Result);
                //#endregion
                
                if (responseData != null)
                {
                    var jsonObject = JsonConvert.SerializeObject(responseData, new JsonSerializerSettings
                    {
                        Formatting = Formatting.Indented
                    });
                }
                return new OkObjectResult(responseData);
        }

        public static string GetToken()
        {
        var client = new RestClient("https://lodgelink-prod.auth0.com/oauth/token");
        var request = new RestRequest(Method.POST);
        request.AddHeader("content-type", "application/json");
        request.AddParameter("application/json", "{\"client_id\":\"HK8Yqj9c5mb1wx2jfHAbUB8dbkTBdHgd\",\"client_secret\":\"GuUzm_yXzmAn2ATslvVcjQi8gYqNSv1-ppi9BTLjtb3XWCC7OHw6jLWDw0f-jLwG\",\"audience\":\"https://lodgelink-prod.auth0.com/api/v2/\",\"grant_type\":\"client_credentials\"}", ParameterType.RequestBody);
        IRestResponse response = client.Execute(request);
        }

//##################### send api #######################
//var client = new RestClient("http://path_to_your_api/");
//var request = new RestRequest(Method.GET);
//request.AddHeader("authorization", "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik5VVXlOalV4TURoQ05FVkdRek5CTlVZMVFrVkdSVVV5T1RkQlJrWTRSakUwUmtZM09VRkJOdyJ9.eyJpc3MiOiJodHRwczovL2xvZGdlbGluay1wcm9kLmF1dGgwLmNvbS8iLCJzdWIiOiJISzhZcWo5YzVtYjF3eDJqZkhBYlVCOGRia1RCZEhnZEBjbGllbnRzIiwiYXVkIjoiaHR0cHM6Ly9sb2RnZWxpbmstcHJvZC5hdXRoMC5jb20vYXBpL3YyLyIsImlhdCI6MTY3NjI4NTI5OCwiZXhwIjoxNjc2MzcxNjk4LCJhenAiOiJISzhZcWo5YzVtYjF3eDJqZkhBYlVCOGRia1RCZEhnZCIsInNjb3BlIjoicmVhZDpjbGllbnRfZ3JhbnRzIGNyZWF0ZTpjbGllbnRfZ3JhbnRzIGRlbGV0ZTpjbGllbnRfZ3JhbnRzIHVwZGF0ZTpjbGllbnRfZ3JhbnRzIHJlYWQ6dXNlcnMgdXBkYXRlOnVzZXJzIGRlbGV0ZTp1c2VycyBjcmVhdGU6dXNlcnMgcmVhZDp1c2Vyc19hcHBfbWV0YWRhdGEgdXBkYXRlOnVzZXJzX2FwcF9tZXRhZGF0YSBkZWxldGU6dXNlcnNfYXBwX21ldGFkYXRhIGNyZWF0ZTp1c2Vyc19hcHBfbWV0YWRhdGEgY3JlYXRlOnVzZXJfdGlja2V0cyByZWFkOmNsaWVudHMgdXBkYXRlOmNsaWVudHMgZGVsZXRlOmNsaWVudHMgY3JlYXRlOmNsaWVudHMgcmVhZDpjbGllbnRfa2V5cyB1cGRhdGU6Y2xpZW50X2tleXMgZGVsZXRlOmNsaWVudF9rZXlzIGNyZWF0ZTpjbGllbnRfa2V5cyByZWFkOmNvbm5lY3Rpb25zIHVwZGF0ZTpjb25uZWN0aW9ucyBkZWxldGU6Y29ubmVjdGlvbnMgY3JlYXRlOmNvbm5lY3Rpb25zIHJlYWQ6cmVzb3VyY2Vfc2VydmVycyB1cGRhdGU6cmVzb3VyY2Vfc2VydmVycyBkZWxldGU6cmVzb3VyY2Vfc2VydmVycyBjcmVhdGU6cmVzb3VyY2Vfc2VydmVycyByZWFkOmRldmljZV9jcmVkZW50aWFscyB1cGRhdGU6ZGV2aWNlX2NyZWRlbnRpYWxzIGRlbGV0ZTpkZXZpY2VfY3JlZGVudGlhbHMgY3JlYXRlOmRldmljZV9jcmVkZW50aWFscyByZWFkOnJ1bGVzIHVwZGF0ZTpydWxlcyBkZWxldGU6cnVsZXMgY3JlYXRlOnJ1bGVzIHJlYWQ6cnVsZXNfY29uZmlncyB1cGRhdGU6cnVsZXNfY29uZmlncyBkZWxldGU6cnVsZXNfY29uZmlncyByZWFkOmVtYWlsX3Byb3ZpZGVyIHVwZGF0ZTplbWFpbF9wcm92aWRlciBkZWxldGU6ZW1haWxfcHJvdmlkZXIgY3JlYXRlOmVtYWlsX3Byb3ZpZGVyIGJsYWNrbGlzdDp0b2tlbnMgcmVhZDpzdGF0cyByZWFkOnRlbmFudF9zZXR0aW5ncyB1cGRhdGU6dGVuYW50X3NldHRpbmdzIHJlYWQ6bG9ncyByZWFkOnNoaWVsZHMgY3JlYXRlOnNoaWVsZHMgZGVsZXRlOnNoaWVsZHMgdXBkYXRlOnRyaWdnZXJzIHJlYWQ6dHJpZ2dlcnMgcmVhZDpncmFudHMgZGVsZXRlOmdyYW50cyByZWFkOmd1YXJkaWFuX2ZhY3RvcnMgdXBkYXRlOmd1YXJkaWFuX2ZhY3RvcnMgcmVhZDpndWFyZGlhbl9lbnJvbGxtZW50cyBkZWxldGU6Z3VhcmRpYW5fZW5yb2xsbWVudHMgY3JlYXRlOmd1YXJkaWFuX2Vucm9sbG1lbnRfdGlja2V0cyByZWFkOnVzZXJfaWRwX3Rva2VucyBjcmVhdGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiBkZWxldGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiByZWFkOmN1c3RvbV9kb21haW5zIGRlbGV0ZTpjdXN0b21fZG9tYWlucyBjcmVhdGU6Y3VzdG9tX2RvbWFpbnMgcmVhZDplbWFpbF90ZW1wbGF0ZXMgY3JlYXRlOmVtYWlsX3RlbXBsYXRlcyB1cGRhdGU6ZW1haWxfdGVtcGxhdGVzIiwiZ3R5IjoiY2xpZW50LWNyZWRlbnRpYWxzIn0.s6bFRgrsGnuSiD4kM7XaniSPflm-RyMEASptXNXBUv52dpFEDjeOvrBW5c3Y6RmJV70baqaQs9vCThD9i--615cCNwU58ZiiRwfI9U1w4DVkK6aR9eonWaOSskgZg9W5tl4FxVxgRtPe1WKe4VQw3n5tAuLEbqJOPcXkGiwejRmtddRYfyoxAe_zFw305EQc9Npp87zLirjEyaF2JMZxLoge56UrmG_De_F25WRDb7yxaziqzDtqBaDVJlUk9xnLld94KRCyLL005_f6LDExfWxn6WRLaJDBn6j6GkIBQyIWS9RtgWuOY9134u8KrEJjKlCaeI_sLhSslHAu2Q8roA");
//IRestResponse response = client.Execute(request);
//#####################################################

        //public async Task<AccessTokenResponse?> Refresh(Auth0WebAppOptions options, string refreshToken)
        //{
            //var body = new Dictionary<string, string> {
              //  { "grant_type", "refresh_token" },
              //  { "client_id", options.ClientId },
              //  { "refresh_token", refreshToken }
            //};

            //ApplyClientAuthentication(options, body);

            //var requestContent = new FormUrlEncodedContent(body.Select(p => new KeyValuePair<string?, string?>(p.Key, p.Value ?? "")));

            //using (var request = new HttpRequestMessage(HttpMethod.Post, $"https://{options.Domain}/oauth/token") { Content = requestContent })
            //{
              //  using (var response = await _httpClient.SendAsync(request).ConfigureAwait(false))
              //  {
              //      if (!response.IsSuccessStatusCode)
              //      {
              //          return null;
              //      }

                //    var contentStream = await response.Content.ReadAsStreamAsync().ConfigureAwait(false);

                  //  return await JsonSerializer.DeserializeAsync<AccessTokenResponse>(contentStream, _jsonSerializerOptions).ConfigureAwait(false);
               // }
            //}
        //}

        //private void ApplyClientAuthentication(Auth0WebAppOptions options, Dictionary<string, string> body)
        //{
          //  if (options.ClientAssertionSecurityKey != null)
            //{
              //  body.Add("client_assertion", new JwtTokenFactory(options.ClientAssertionSecurityKey, options.ClientAssertionSecurityKeyAlgorithm ?? SecurityAlgorithms.RsaSha256)
                //   .GenerateToken(options.ClientId, $"https://{options.Domain}/", options.ClientId
                //));

            //    body.Add("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer");
          //  }
          //  else
          //  {
           //     body.Add("client_secret", options.ClientSecret!);
         //   }
       // }


    } 

}