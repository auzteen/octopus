using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using LodgeLink.Model;


namespace Lodgelink
{
    public static class GetScore
    {
        private static HttpClient httpClient = new HttpClient();
        //private static string GET_URL = "https://api-eu.securitycenter.microsoft.com/api/configurationScore"; // Change these uri for GET
        private static string GET_DEFENDER_SCORE_URI = "https://api.securitycenter.microsoft.com/api/configurationScore";
        //private static string POST_URL = "https://dummyjson.com/products/add";


        [FunctionName("GetScore")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

                #region Defender Score Get Request
                var request = new HttpRequestMessage(HttpMethod.Get, GET_DEFENDER_SCORE_URI);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
                var response = httpClient.SendAsync(request).GetAwaiter().GetResult();
                var result = response.Content.ReadAsStringAsync();
                var responseData = JsonConvert.DeserializeObject<ScoreData>(result.Result);
                #endregion

                if (responseData != null)
                {
                    var jsonObject = JsonConvert.SerializeObject(responseData, new JsonSerializerSettings
                    {
                        Formatting = Formatting.Indented
                    });
                   // var jwt_token = "xxxxxxxxxxxxx";
                   // httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", jwt_token);
                   // var httpContent = new StringContent(jsonObject, System.Text.Encoding.UTF8, "application/json");
                   // httpContent.Headers.Add("X-Company-Short", "open");
                   // var respMessage = await httpClient.PostAsync(POST_URL, httpContent);
                   // var postResp = await respMessage.Content.ReadAsStringAsync();
                   // logger.LogInformation($"Post function executed at: {DateTime.Now}{postResp}");
                   // return new OkObjectResult(postResp);
                }

            return new OkObjectResult(responseData.Score);
        }
        public static string GetToken()
        {
            string tenantId = "f15a052c-b71c-4205-a7fa-4b11e209f53a";
            string appId = "08fe282b-18ff-4968-940e-5a57211ea338";
            string appSecret = "jG08Q~lsTfRgjr0oOxrm8-Va3YWeTrFB2czo.bOb";
            const string authority = "https://login.microsoftonline.com";
            const string audience = "https://api.securitycenter.microsoft.com";
            IConfidentialClientApplication myApp = ConfidentialClientApplicationBuilder.Create(appId).WithClientSecret(appSecret).WithAuthority($"{authority}/{tenantId}").Build();
            List<string> scopes = new List<string>() { $"{audience}/.default" };
            AuthenticationResult authResult = myApp.AcquireTokenForClient(scopes).ExecuteAsync().GetAwaiter().GetResult();
            return authResult.AccessToken;
        }

    }
}
