using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using LodgeLink.Model;


namespace Lodgelink
{
    public static class GetAlerts
    {
        private static HttpClient httpClient = new HttpClient();
        private static string GET_URL = "https://api.securitycenter.microsoft.com/api/alerts"; // Change these uri for GET

        [FunctionName("GetAlerts")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

                //#region Defender Alerts
                var request = new HttpRequestMessage(HttpMethod.Get, GET_URL);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
                var response = httpClient.SendAsync(request).GetAwaiter().GetResult();
                var result = response.Content.ReadAsStringAsync();
                var responseData = JsonConvert.DeserializeObject<AlertData>(result.Result);
                //#endregion
                log.LogInformation(result.Result);

                if (responseData != null && responseData.Value?.Length > 0)
                {
                    var jsonObject = JsonConvert.SerializeObject(responseData, new JsonSerializerSettings
                    {
                        Formatting = Formatting.Indented
                    });
                }

            return new OkObjectResult(responseData);
        }

        public static string GetToken()
        {
            string tenantId = "f15a052c-b71c-4205-a7fa-4b11e209f53a";
            string appId = "08fe282b-18ff-4968-940e-5a57211ea338";
            string appSecret = "jG08Q~lsTfRgjr0oOxrm8-Va3YWeTrFB2czo.bOb";
            const string authority = "https://login.microsoftonline.com";
            const string audience = "https://api.securitycenter.microsoft.com";
            IConfidentialClientApplication myApp = ConfidentialClientApplicationBuilder.Create(appId).WithClientSecret(appSecret).WithAuthority($"{authority}/{tenantId}").Build();
            List<string> scopes = new List<string>() { $"{audience}/.default" };
            AuthenticationResult authResult = myApp.AcquireTokenForClient(scopes).ExecuteAsync().GetAwaiter().GetResult();
            return authResult.AccessToken;
        }


    } 

}